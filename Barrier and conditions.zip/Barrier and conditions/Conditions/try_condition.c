#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

typedef struct Cond{
  pthread_mutex_t lock;	
  pthread_cond_t mycond;
  int i;
}Cond;

int  st_m,st_c;
Cond c;

static void 
*ta(void *args){

  while(1){
    sleep(st_c);
    pthread_mutex_lock(&c.lock);
    printf("Thread blocked\n");
    pthread_cond_wait(&c.mycond, &c.lock);
    printf("Thread a signalled\n");
    pthread_mutex_unlock(&c.lock);
  }

  return 0;
}

int main(int argc, char **argv)
{
  int  i, n;
  pthread_t  t_a;

  if(argc < 4){
	fprintf(stderr, "Syntax: %s num_cond_signals sleep_time_main, sleep_time_created\n", argv[0]);
	exit(1);  
  }

  n = atoi(argv[1]);
  st_m = atoi(argv[2]);
  st_c = atoi(argv[3]);
  pthread_create(&t_a, NULL, ta, NULL);
  
  sleep(st_m);  


  for (i=0;i<n;i++){
    printf("Wake up thread a \n");
    pthread_mutex_lock(&c.lock);
    pthread_cond_signal(&c.mycond);
    pthread_mutex_unlock(&c.lock);
  }

  exit(0);
}

