	#include <stdio.h>
	#include "pthread.h"
	#include "semaphore.h"
	#include <stdlib.h>
	#include <unistd.h>
	sem_t *sem,*sem2,*sem3;
	int g,reachEnd,semval1,semval2;
	FILE *fp1,*fp2;

	static void *
	threadFunc (void *data){

	 pthread_t pid = pthread_self();
	 int  var1, var2,ending2=0,ending=0;
  		while(1){

		sem_wait(sem) ;
		sem_getvalue(sem,&semval1);
			//printf("1st global %d th id is %ld sem_getvalue %d \n",g,pid,semval1 );

		if(fread(&var1, sizeof(int),1,fp1 )!=1){
			if(feof(fp1)){
		    printf("reached end of file 1 \n");	
 			if (ending2 ==1)  {
				reachEnd++;  // if both files reach end of file, break. and  increament the glabal flag
  				printf("both files reached end of file %d \n ",reachEnd); 
				break;
				}
				else  {ending =1;}
			}
			else{
				printf("error reading binary \n");	 
				return 0;
			   }
		}		
		else
		{ 
			printf("  file 1 binary value  = %d  \n", var1 );  
			 g=var1 ; 
			sleep(1);
		}
			
	 	sem_post(sem2);				//signal to the server andd wait the result on sem3 

		sem_wait(sem3);	
		sem_getvalue(sem3,&semval2);
		printf("\n after computation (first file)  %d thread id =  %ld sem_getvalue %d \n\n",g,pid,semval2 );

		sleep(2); // read from the file 2 the sem is already yours (;
			if(fread(&var2, sizeof(int),1,fp2 )!=1){
			
			   if(feof(fp2)){
				printf("reached end of file 2 \n");	
					if (ending ==1)  {
						reachEnd++;           // if both files reach end of file, break. and  increament the glabal flag
			 			printf("both files reached end of file %d \n ",reachEnd);  
						break;
						}
					else  {ending2 =1;}
				}
				else
				{
					 printf("error reading binary \n");	 
			         return 0;	 
				}
			}
			else
			{ 
		     printf(" file 2  binary value = %d  \n",var2); 
	 	     g=var2 ;
		     sleep(1); 
			} 
		 sem_post(sem2);	
		 sleep(2);  
		 sem_wait(sem3); 
		 printf("\n after computation (second file) %d thread id= %ld sem_getvalue %d \n\n",g,pid,semval2 );
		 sem_post(sem);  //let this thread or other thread continue workinig
		 sleep(2);
	}  
	printf("out of the while loop %d \n",reachEnd);
	sem_post(sem2);
	pthread_exit((void *) 1);  
	}

	int
	main (void){
	 
		int i,var1,servedcount =0 ;
		pthread_t *th_a ;
		void *retval; 
		sem= (sem_t *) malloc (sizeof(sem_t));
	 	sem2= (sem_t *) malloc (sizeof(sem_t));
	 	sem3= (sem_t *) malloc (sizeof(sem_t));
	 	sem_init (sem, 0, 1);
	 	sem_init (sem2, 0, 0);
	 	sem_init (sem3, 0, 0);
	 	 

		reachEnd=0;
		
	 	fp1 = fopen("fv2.b","rb");
		  if(fp1==NULL){printf("error opening file1 binary \n"); return (0);}  
	 	   
	 

		  fp2 = fopen("fv2.b","rb");
		  if(fp2==NULL){printf("error opening file2 binary \n"); return (0);}  
		  
	 	 th_a = (pthread_t *)malloc(sizeof(pthread_t)*2);
		/* Create the threads */
		for(i = 0 ; i<2 ; i++)
		pthread_create (&th_a[i], NULL, threadFunc, 0);
		
		while(1){
				sem_wait(sem2);
				if(reachEnd>=1) break;
				printf("\n the server is processing your request \n");
				g=g*3;
				servedcount++;
				sem_post(sem3);
		}
	printf("\n work is done from both threads. %d clients served  \n",servedcount);
	 	/* Wait until the two threads finish. */
		
		/*for(i = 0 ; i<2 ; i++)
		if(pthread_join(th_a[i], &retval)) printf("joining erro \n"); return 0;*/

	//printf("\n closing the server gracefully ");
		
		return 0;
	}