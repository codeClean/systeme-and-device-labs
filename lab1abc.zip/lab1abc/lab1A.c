/*generate  random numbers 
 fill vectors
 save in to text and binary format files
*/
	#include <stdio.h>
	#include <stdlib.h>
	#include <unistd.h>
	#include <pthread.h>

 

int random_even(int min, int max){
	int even;
		while(1)
		{
		even = (int)(rand() % (max - min + 1)) + min;
		if(even%2==0) break ;
		}
	  return even;
	}	
	
int random_odd(int min, int max){	
	int odd;
		while(1)
		{
		 odd = (int)(rand() % (max - min + 1)) + min;
		 if(odd%2!=0) break ;
		}
	  return odd;
	}


 void sortfunc(int *var, int count)
{
	int i,j,temp;
	
	for(i=0; i< count; i++)
	{
	   for(j=i+1; j< count; j++)
		{ 
		  if(var[i] > var[j]){
		    temp = var[j];
		    var[j] = var[i];
		    var[i] = temp;
		   }		   
		}
	}	
}
	
 int main (int argc, char *argv[]){

	int even,odd,i; 
	int num1,num2;
	FILE *fp1;
	 
	if(argc!=3){printf("usage num1 and num2 \n"); return (0);}

	num1 = atoi(argv[1]);
	num2 = atoi(argv[2]);

	int var1[num1], var2[num2] ;	 
	
	for(i =0; i<num1; i++)
	{
		even = random_even(10,100);
		var1[i]=even;
		//printf("even number enserted %d \n",var1[i]);
	}
	for(i =0; i<num2; i++)
	{
		odd = random_odd(10,100);
		var2[i]=odd;
		//printf("odd number enserted %d \n",var2[i]);
	} 

	sortfunc(var1,num1);
	sortfunc(var2,num2);
	/*for(i =0; i<num1; i++){ printf("var 1 after sort %d \n",var1[i]); }*/

	///  write in text format
	 fp1 = fopen("fv1.txt","wt");
	  if(fp1==NULL){printf("error opening file1 \n"); return (0);}

	  for (int i = 0; i < num1; ++i) fprintf(fp1, "%d",var1[i] );
	  fclose(fp1);

	  fp1 = fopen("fv2.txt","wt");
	  if(fp1==NULL){printf("error opening file2 \n"); return (0);}

	  for (int i = 0; i < num2; ++i) fprintf(fp1, "%d",var2[i] );
	  fclose(fp1);

	  ///  write binary format
	
	  fp1 = fopen("fv1.b","wb");
	  if(fp1==NULL){printf("error opening file1 binary \n"); return (0);}  
	  fwrite(var1, sizeof(int),1,fp1 );	  
	  fclose(fp1);
	   

	  fp1 = fopen("fv2.b","wb");
	  if(fp1==NULL){printf("error opening file1 binary \n"); return (0);}  
	  fwrite(var2, sizeof(int),2,fp1 );	  
	  fclose(fp1);

  pthread_exit (NULL);
}
