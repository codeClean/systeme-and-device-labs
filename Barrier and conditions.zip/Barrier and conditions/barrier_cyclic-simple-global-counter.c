#include <stdio.h>
#include <stdlib.h>
#include "pthread.h"
#include "semaphore.h"

sem_t *barrier1, *barrier2;

typedef struct {
  int count;
  pthread_mutex_t mutex;
} Counter;

Counter *c;
int num_threads;

static void *
code (void *arg){
	int i, j, r;
	
  pthread_detach (pthread_self ());
  for (i=0;i<10;i++){
  r =	random() % 5;
  sleep(r);
  printf("%ld slept %d  sec in phase 1\n", pthread_self(), r);
  pthread_mutex_lock (&c->mutex);
    c->count++;
    if (c->count == num_threads)
    	for (j=0;j<num_threads;j++)
    	  sem_post(barrier1);
  pthread_mutex_unlock (&c->mutex);
    
  sem_wait(barrier1);	
  
  printf("%ld phase 2\n", pthread_self());
  
  pthread_mutex_lock (&c->mutex);
    c->count--;
    if (c->count == 0) 
    	for (j=0;j<num_threads;j++)
    	  sem_post(barrier2);
  pthread_mutex_unlock (&c->mutex);
  
  sem_wait(barrier2);
}
  return  0;
}  

int
main (int argc, char ** argv)
{
  pthread_t *th;
  void *retval;

  int i;
  
  if (argc != 2) {
    printf ("Syntax: %s num_threads\n", argv[0]);
    return (1);
  }
  num_threads = atoi(argv[1]);
  th = (pthread_t *) malloc (num_threads * sizeof(pthread_t));
  c = (Counter *) malloc (sizeof(Counter));
  c->count = 0;
  pthread_mutex_init (&c->mutex, NULL);
  barrier1 = (sem_t *) malloc(sizeof(sem_t));
  sem_init (barrier1, 0, 0);
  barrier2 = (sem_t *) malloc(sizeof(sem_t));
  sem_init (barrier2, 0, 0);
  
    /* Create the threads */
  for (i=0;i< num_threads; i++)
    pthread_create (&th[i], NULL, code, NULL);
  
  pthread_exit ((void *) pthread_self());
    
  return 0;
}
