#include <stdio.h>
#include <stdlib.h>
#include "pthread.h"
#include "semaphore.h"

typedef struct List_elem
{
  sem_t *sem;
  int priority;
  struct List_elem *next;
} List_elem;

typedef struct Sem
{
	sem_t *mutex;
  int cnt;
  List_elem *sem_list;
} Sem;

Sem *S_init (int value);
sem_t *enqueue_sorted (List_elem * head, int priority);
sem_t *dequeue_sorted (List_elem * head);
void S_wait (Sem * s, int prio);
void S_signal (Sem * s);

Sem *S1, *S2;


Sem *
S_init (int value)
{
  Sem *s;
  s = (Sem *) malloc (sizeof (Sem));
  s->cnt = value;
  s->mutex = (sem_t *) malloc (sizeof (sem_t));
  sem_init (s->mutex, 0, 1);
  s->sem_list = (List_elem *) malloc (sizeof (List_elem));      // create empty queue with sentinels
  s->sem_list->priority = -1;
  s->sem_list->next = (List_elem *) malloc (sizeof (List_elem));
  s->sem_list->next->priority = 1000000;
  s->sem_list->next->next = NULL;
  return s;
}

void
S_wait (Sem * s, int prio){
  sem_t *new_sem;

  sem_wait (s->mutex);
  if (--s->cnt < 0) {
    new_sem = enqueue_sorted (s->sem_list, prio);
    sem_post (s->mutex);
    sem_wait (new_sem);
    sem_destroy (new_sem);
  }
  else
    sem_post (s->mutex);
}

void
S_signal (Sem * s)
{
  sem_t *sem;

  sem_wait (s->mutex);
  if (++s->cnt <= 0) {
    sem = dequeue_sorted (s->sem_list);
    sem_post (sem);
  }
  sem_post (s->mutex);
}


sem_t *
enqueue_sorted (List_elem * head, int priority)
{
  List_elem *p, *new_elem;

  p = head;                     // search
  while (priority > p->next->priority)
    p = p->next;

  new_elem = (List_elem *) malloc (sizeof (List_elem));
  new_elem->sem = (sem_t *) malloc (sizeof (sem_t));
  sem_init (new_elem->sem, 0, 0);
  new_elem->priority = priority;
  new_elem->next = p->next;
  p->next = new_elem;
  printf("%u with priority = %d  waits on sem %p\n",
           pthread_self(), priority, new_elem->sem);

  return new_elem->sem;
}

sem_t *
dequeue_sorted (List_elem * head)
{
  List_elem *p;
  sem_t *s;

  p = head->next;
  s = head->next->sem;
  printf("%u with priority = %d awakes from sem %p\n",
         pthread_self(), head->next->priority, s);
  head->next = head->next->next;
  free (p);
  return s;
}

static void *
runner (void *arg)
{
  int *i = (int *) arg;
  pthread_detach (pthread_self ());
  sleep (random () % 5);
  printf ("request from %u %d\n", pthread_self (), *i);
  S_wait (S1, *i);
  printf ("service of   %u %d\n", pthread_self (), *i);
  return 0;
}


int
main (void)
{
  pthread_t th_a;
  int i, *pi;

  setbuf (stdout, 0);

  S1 = S_init (0);

  for (i = 1; i <= 4; i++) {
    pi = (int *) malloc (sizeof (int));
    *pi = i * 10;
    pthread_create (&th_a, NULL, runner, pi);
  }

  sleep (10);

  for (i = 0; i < 4; i++) {
    S_signal (S1);
    sleep(1);
  }


  printf ("main exiting\n");

  pthread_exit (0);
}
