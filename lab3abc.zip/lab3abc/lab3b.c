#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "pthread.h"


#define buffSize 5

typedef struct mycond
{
	pthread_mutex_t lock;
	pthread_cond_t notempty;
	pthread_cond_t notfull;
	int count;
	int in;
	int out;
	int *buffer;
}cond_t;
cond_t cond;

void init_cond (int size){  

	cond.buffer= (int *)malloc(sizeof(int)*buffSize);
	pthread_mutex_init(&cond.lock,NULL);
	pthread_cond_init(&cond.notempty,NULL);
	pthread_cond_init(&cond.notfull,NULL);
	cond.in=0;
	cond.out=0;
	cond.count=0;
}
void put(int val){
	sleep(1);

	pthread_mutex_lock(&cond.lock);

	while(cond.count>=buffSize){
		pthread_cond_wait(&cond.notfull,&cond.lock);
	}
	cond.buffer[cond.in]=val;
	//printf("in val %d \n", cond.in);
	cond.in++;
	
	/*int testin = cond.in % buffSize;
	printf("modulo in %d \n", testin );*/
	if(cond.in >= buffSize) {printf("reach putting bsize\n");cond.in=0;}
	/*else{
	
	printf("cod in become %d \n",cond.in );	
	} */
	cond.count++;
	printf("in val AFTER  %d \n", cond.in);
	pthread_cond_signal(&cond.notempty);
	pthread_mutex_unlock(&cond.lock);

}
int get(){

	sleep(4);
	int valreturned;
	pthread_mutex_lock(&cond.lock);
	while(cond.count<=0){
		pthread_cond_wait(&cond.notempty,&cond.lock);
	}
	/*printf("\n out val %d buffer size %d \n", cond.out,buffSize);
		cond.out++;

int test = cond.out%buffSize;*/
	//printf("moduldo out %d \n",test );
	valreturned = cond.buffer[cond.out];
	cond.out++;
	if(cond.out > buffSize==0){printf("reach geting bsize\n");cond.out=0;}
	/*else
	{
		printf("cod out become %d \n",cond.out);
	}*/
	cond.count--;
		//printf("\n after  %d \n", cond.out);

	pthread_cond_signal(&cond.notfull);

	pthread_mutex_unlock(&cond.lock);
	return valreturned;

}

static void *consumer(void *argc){
	int val;

	while(1)
	{
		val = get();
		printf("got %d from the buffer \n",val );

	}
}

static	void *producer (void *argc){

	int i;

	for (int i = 0; i < 15; ++i)
	{
		printf(" about to put %d to the buffer \n\n", i);
		put(i);
		printf(" puted successfuly \n\n");
	}

}

int  main(int argc, char const *argv[])
{
	pthread_t thcon, thprod;

	init_cond(buffSize);

	pthread_create(&thcon,NULL,consumer,NULL);
	pthread_create(&thprod,NULL,producer,NULL);
	

	pthread_exit((void *)1);
}