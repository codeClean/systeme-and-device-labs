#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "pthread.h"

typedef struct Cond{
  pthread_mutex_t lock;  
  pthread_cond_t  cond;
  int             conditionMet;
} Cond;

Cond cond;

#define NTHREADS    5

static void *
threadfunc(void *args){
  int id = *(int *) args;
  
  pthread_mutex_lock(&cond.lock);
  while (!cond.conditionMet) {
    printf("Thread %d blocked\n", id);
    pthread_cond_wait(&cond.cond, &cond.lock);
  }
  pthread_mutex_unlock(&cond.lock);
  
  printf("Thread %d signaled\n", id);
  return NULL;
}

int main(int argc, char **argv)
{
  int i, *pi;
  pthread_t threadid[NTHREADS];

  pthread_cond_init(&cond.cond, NULL);
  pthread_mutex_init(&cond.lock, NULL);
  
  printf("Create %d threads\n", NTHREADS);
  for(i=0; i<NTHREADS; ++i) {
     pi = (int *) malloc(sizeof(int));
    *pi = i;
    pthread_create(&threadid[i], NULL, threadfunc, pi); 
  }

  sleep(5);
  
  pthread_mutex_lock(&cond.lock);
  cond.conditionMet = 1;
  printf("Wake up all waiting threads...\n");
  pthread_cond_broadcast(&cond.cond);
  pthread_mutex_unlock(&cond.lock);


  printf("Wait for threads\n");
  for (i=0; i<NTHREADS; ++i) 
    pthread_join(threadid[i], NULL);

  printf("Main completed\n");
  return 0;
}
