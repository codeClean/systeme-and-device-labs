	/*
	 Create two child.
	 Each child will creates the file. 
	 The parent will wait for the children to finish.
	 The parent prints the children id and status.
	*/
	#include <stdio.h>
	#include <stdlib.h>
	#include <unistd.h>
	#include <pthread.h>
	#include <sys/types.h>
	#include <sys/wait.h>
 

int random_even(int min, int max){
	int even;
		while(1)
		{
		even = (int)(rand() % (max - min + 1)) + min;
		if(even%2==0) break ;
		}
	  return even;
	}	
	
int random_odd(int min, int max){	
	int odd;
		while(1)
		{
		 odd = (int)(rand() % (max - min + 1)) + min;
		 if(odd%2!=0) break ;
		}
	  return odd;
	}


 void sortfunc(int *var, int count)
{
	int i,j,temp;
	
	for(i=0; i< count; i++)
	{
	   for(j=i+1; j< count; j++)
		{ 
		  if(var[i] > var[j]){
		    temp = var[j];
		    var[j] = var[i];
		    var[i] = temp;
		   }		   
		}
	}	
}
	
 int main (int argc, char *argv[]){

	int even,odd,i; 
	int num1,num2,status1,status2;
	pid_t pid1,pid2,chid1,chid2;
	FILE *fp1;
	 
	if(argc!=3){printf("usage num1 and num2 \n"); return (0);}

	num1 = atoi(argv[1]);
	num2 = atoi(argv[2]);

	int var1[num1], var2[num2] ,var3[num2];	 
	
	for(i =0; i<num1; i++)
	{
		even = random_even(10,100);
		var1[i]=even;
		//printf("even number enserted %d \n",var1[i]);
	}
	for(i =0; i<num2; i++)
	{
		odd = random_odd(10,100);
		var2[i]=odd;
		//printf("odd number enserted %d \n",var2[i]);
	} 

	sortfunc(var1,num1);
	sortfunc(var2,num2);
	/*for(i =0; i<num1; i++){ printf("var 1 after sort %d \n",var1[i]); }*/

	///  write in text format
	pid1 = fork();
	if(pid1==0)
	{
	  fp1 = fopen("fv1.txt","wt");
	  if(fp1==NULL){printf("error opening file1 \n"); return (0);}

	  for (int i = 0; i < num1; ++i) fprintf(fp1, "%d ",var1[i] );
	  fclose(fp1);

	///  write binary format
	fp1 = fopen("fv1.b","wb");
	  if(fp1==NULL){printf("error opening file1 binary \n"); return (0);}  
	  fwrite(var1, sizeof(int),1,fp1 );	  
	  fclose(fp1);

	  exit (1);
	}
	pid2 = fork();
	if(pid2==0)
	{
	  fp1 = fopen("fv2.txt","wt");
	  if(fp1==NULL){printf("error opening file2 \n"); return (0);}
	 for (int i = 0; i < num2; ++i) //fprintf(fp1, "%d ",var2[i] ); 
	  fclose(fp1);


	///  write binary format
	fp1 = fopen("fv2.b","wb");
	  if(fp1==NULL){printf("error opening file1 binary \n"); return (0);}  
	  fwrite(var2, sizeof(int),num2,fp1 );	  
	  fclose(fp1);
	exit (2);
	}

	sleep(3);

	

	chid1  = wait(&status1);
	chid2 = wait(&status2);
	if(WIFEXITED(status1)) printf("child 1 with pid %d exited with status %d \n", chid1,WEXITSTATUS(status1));
	if(WIFEXITED(status2)) printf("child 2 with pid %d exited with status %d \n", chid1,WEXITSTATUS(status2));

printf("about to read from file\n");
	fp1 = fopen("filetest.b","rb");
	  if(fp1==NULL){printf("error opening filetest binary \n"); return (0);}  
	  fread(var3, sizeof(int),12,fp1 );	  
	  fclose(fp1);
	
for (int i = 0; i < 12; ++i)
{
	printf("reading from file %d \n",var3[i] );
}

  pthread_exit (NULL);
}
