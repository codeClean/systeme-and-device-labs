/* The main trhead creates three threads.
   Two of the threads update a variable.
   The third thread waits until the  count variable reaches a specified value. 
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "pthread.h"

#define NUM_THREADS  3
#define COUNT 10
#define COUNT_LIMIT 12

typedef struct Cond{
  pthread_mutex_t lock;  
  pthread_cond_t  cond;
  int             count;
} Cond;

int thread_ids[3] = {0,1,2};
Cond cond;


static void *
inc_count(void *args) {
  int my_id = *(int *) args;
  int i;
  
  for (i=0; i<COUNT; i++) {
    pthread_mutex_lock(&cond.lock);
    cond.count++;

    if (cond.count == COUNT_LIMIT) {
      pthread_cond_signal(&cond.cond);
      printf("inc_count thread %d, count = %d  Threshold reached.\n", my_id, cond.count);
    }
    pthread_mutex_unlock(&cond.lock);

   sleep(1);
  }
  pthread_exit(0);
}

static void *
watch_count(void *args){
  int my_id = *(int *) args;

  printf("Starting watch_count thread %d\n", my_id);

  pthread_mutex_lock(&cond.lock);
  if (cond.count<COUNT_LIMIT) {
    pthread_cond_wait(&cond.cond, &cond.lock);
    printf("watch_count thread %d Condition signal received.\n", my_id);
  }
  pthread_mutex_unlock(&cond.lock);
  pthread_exit(0);
}


int main (){
  pthread_t threads[3];
  setbuf(stdout, 0);

  /* Initialize mutex and condition variable objects */
  pthread_mutex_init(&cond.lock, NULL);
  pthread_cond_init (&cond.cond, NULL);

  pthread_create(&threads[0], NULL, inc_count,   (void *) &thread_ids[0]);
  pthread_create(&threads[1], NULL, inc_count,   (void *) &thread_ids[1]);
  pthread_create(&threads[2], NULL, watch_count, (void *) &thread_ids[2]);
  
  pthread_exit(0);

}


