#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <time.h>
#include <assert.h>
#include <errno.h>
#include <signal.h>
#include <stddef.h>
 #include <sys/time.h> 
#include "pthread.h"
 
#define maxlen 10
#define maxbuff 20

//pthread_mutex_t me1,me2;

typedef struct 
{
	int in;
	int out;
	long long bufferval[maxbuff]; 
	char bufftype[maxlen];
	int zeris;
	
}buffer_t;
buffer_t urgentbf,normalbf; 

sem_t urgentFull,urgentEmpty,normalFull,normalEmpty;

int dorandom(int min, int max){
	int ran = (int)(rand() % (max - min + 1)) + min; 
	  return ran;
	}

long long current_timestamp (){
	struct timeval te;
	gettimeofday(&te,NULL); // gets the current time
	long long milisec = te.tv_sec*1000LL + te.tv_usec/1000;
	return milisec;
}

int put(long long ms, char bufftype[maxlen])
{
	if(strcmp(bufftype,"urgent")==0){
		sem_wait(&urgentEmpty);
		urgentbf.bufferval[urgentbf.in]=ms;
		strcpy(urgentbf.bufftype,"urgent");
		urgentbf.in = (urgentbf.in+1) % maxbuff;
		sem_post(&urgentFull);
		return 0;
	}
	else if(strcmp(bufftype,"normal")==0){
		sem_wait(&normalEmpty);
		normalbf.bufferval[normalbf.in]=ms;
		strcpy(normalbf.bufftype,"normal");
		normalbf.in = (normalbf.in+1) % maxbuff;
		sem_post(&normalFull); 
		return 0;
	}
	else
	{
		printf("wrong buffer type \n");
		return 1;
	}
}

buffer_t get(){
	buffer_t buff;
	 int semval,semv2,rc;
	 sem_getvalue(&urgentFull,&semval);
	 sem_getvalue(&normalFull,&semv2);

 	//  printf("semaphore values urgent %d normal %d\n",semval,semv2); 
	 
		rc=sem_trywait(&urgentFull);
		//printf("%d sem_trywait val %d \n",rc,errno );
		if(rc!=-1){
			//urgent has value, fill and return;
			buff = urgentbf; 
			buff.zeris=1;
			urgentbf.out= (urgentbf.out +1) % maxbuff;
			sem_post(&urgentEmpty);
			return buff; 
		}
		else if(sem_trywait(&normalFull)!=-1){
			//normal  has value, fill and return;
			buff = normalbf; 
			buff.zeris=1;
			normalbf.out= (normalbf.out +1) % maxbuff;
			sem_post(&normalEmpty);
			return buff;
		} 
		else {
			printf("the buffer is empty\n");
			buff.zeris=0;
			return buff;
		}

	 
}

static void *producer(void *argc){

	int i,randval,ret;
	long long ms,waitms;
	char bufftype[maxlen];

 	for (  i = 0; i < 10000; ++i)
	{
		waitms = dorandom(1,10);
		usleep(waitms*1000000);
		ms = current_timestamp();
		randval = dorandom(1,100);

		if (randval>=80) { strcpy(bufftype,"urgent"); }
		else {strcpy(bufftype,"normal");}
		printf("puting %lld  in buffer %s \n",ms, bufftype );
	    ret=put(ms,bufftype);
		if(ret) break;
	}
	pthread_exit((void *)1);
}

static void *consumer(void *argc){
	int i;
	buffer_t buff;
	while(1)
	{
		sleep(10);
		buff = get();
		//printf("is thre value %d ",buff.zeris);
		if (buff.zeris==1)
		{
			printf("the value of ms is %lld buffer type %s \n",
					buff.bufferval[buff.out],buff.bufftype);
		}
		else printf("\n will try again in 10 sec \n");
	}  
		pthread_exit((void *)1);
} 

int main(int argc, char const *argv[])
{
	pthread_t thpro, thcon;
	void *retval;
	int res;


sem_init(&urgentEmpty,0,maxbuff); 
sem_init(&normalEmpty,0,maxbuff);
sem_init(&urgentFull,0,0);
sem_init(&normalFull,0,0);  

	urgentbf.out = 0;
	normalbf.out = 0;
	urgentbf.in = 0;
	normalbf.in = 0;
	urgentbf.zeris = 0;
	normalbf.zeris = 0;
	/*for (int i = 0; i < maxbuff; i++)
	{
		urgentbf.bufferval[i]=0;  
		normalbf.bufferval[i]=0;
	}*/
	 
	pthread_create (&thpro,NULL, producer,NULL);
	pthread_create (&thcon,NULL, consumer,NULL);


	res = pthread_join(thpro,&retval);
	if (res==1) { printf("joining producer thread error\n");  return 1; }

	res = pthread_join(thcon,&retval); 
	if (res==1) { printf("joining producer thread error\n"); return 1; 	}

	printf("all threads are done. closing gracefully \n");
	return 0;
}