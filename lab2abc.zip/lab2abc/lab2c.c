#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <time.h>
#include <assert.h>
#include <errno.h>
#include <signal.h>
#include <ctype.h>
#include "pthread.h"

sem_t sem; 
int timemax=0;

int dorandom(int min, int max){
	int ran = (int)(rand() % (max - min + 1)) + min;
		 
	  return ran;
	}

static void timesig(int mili)
{
	printf("about to post the semaphore\n");
	sem_post(&sem); 
}

int wait_with_timeout(sem_t *s, int timem){
	int ret;
	struct  timespec ts;
	ts.tv_sec = time(NULL) + timem / 1000;   // users should insert the timemax in millisecond
    ts.tv_nsec = (timemax % 1000) * 1000000;
    printf("i will wait for the semaphore for %d miliseconds \n",timem);
    while((ret=sem_timedwait(s,&ts))==-1 && errno==EINTR) continue;
    if (ret==-1)
    {	if(errno==ETIMEDOUT){return 1;}
    	else {printf("error timed wait\n"); return 3;}
    }
    else  { return 0;  }  
}

static void *thread1(void *argc)
{ 
		int waitsec,retval;
		int milisec,s;

		waitsec = (int)(rand() % 5) + 1;  
		milisec = waitsec*1000; 
		usleep(milisec*1000);						// usleep expectes nono second so we had to convert

		printf("waiting on semaphore after %d miliseconds\n", milisec);

		retval = wait_with_timeout(&sem,timemax);
		if (retval==1)   {  	printf("wait on semaphore returned for timeout \n");    }

		else if (retval==3) {
		printf("something goes wrong while waiting\n");
		pthread_exit((void *)1); 
		}
		else  { printf("wait returned normally \n");  } 
		//pause();
		pthread_exit((void *)1); 
}

static void *thread2(void *argc){
		printf("thread2\n");
		int _mili,insec;
		_mili  =dorandom(1000,10000);

		insec = _mili/1000; //since alarm use seconds, we have to convert first 

		printf("performing signal on semaphore sem after %d milliseconds  %d (seconds)\n",_mili,insec); 
		alarm(insec); 

 pthread_exit((void *)1); 
}


int main(int argc, char const *argv[])
{
	 struct  timespec ts; 
	 pthread_t tha, thb;
	 void *retval;
	 long int s;

	 if (argc !=2 )
	 {
	 	printf("%s usage: time max (in millisecond )\n",argv[0] );	 	
	 	return 0;
	 }
	signal(SIGALRM,timesig); 
 
 	sem_init(&sem,0,0);
	timemax = atoi(argv[1]);



//tha = (pthread_t *) malloc (sizeof(pthread_t));
 pthread_create(&tha, NULL,thread1, NULL);
 
 pthread_create(&thb, NULL,thread2, NULL);
 
 	printf("will sleep for  :%d milliseconds\n",timemax);

 	int rc = pthread_join(tha,&retval);
 	if (rc!=0) { printf("error on joining tha \n");printf("rc = %d \n",rc); return 0; }
	rc = pthread_join(thb,&retval);
 	if (rc!=0) { printf("error on joining thb \n");printf("rc = %d \n",rc); return 0; }
 	//s = (long int) retval; 

printf("all threads are done. closing gracefully  \n");
 return 0;

	//pthread_exit((void *)1);
}