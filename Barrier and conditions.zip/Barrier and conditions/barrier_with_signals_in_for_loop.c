#include <stdio.h>
#include <stdlib.h>
#include "pthread.h"
#include "semaphore.h"

sem_t *barrier;

typedef struct {
  int count;
  pthread_mutex_t mutex;
} Counter;

Counter *c;
int num_threads;

static void *
code (void *arg){
  int i;
  
  pthread_detach (pthread_self ());
  sleep(random() % 5);
  printf("%ld, 1\n", pthread_self());

  pthread_mutex_lock (&c->mutex);
  c->count++;
  if (c->count == num_threads) 
    for (i=0;i<num_threads)
      sem_post(barrier);
  pthread_mutex_unlock (&c->mutex);
  
  sem_wait(barrier);	
  printf("%ld, 2\n", pthread_self());
  return  0;
}  

int
main (int argc, char ** argv)
{
  pthread_t *th;
  void *retval;
  int i;
  
  if (argc != 2) {
    fprintf (stderr, "Syntax: %s num_threads\n", argv[0]);
    return (1);
  }
  num_threads = atoi(argv[1]);
  th = (pthread_t *) malloc (num_threads * sizeof(pthread_t));
  c = (Counter *) malloc (sizeof(Counter));
  c->count = 0;
  pthread_mutex_init (&c->mutex, NULL);
  barrier = (sem_t *) malloc(sizeof(sem_t));
  sem_init (barrier, 0, 0);
  
    /* Create the threads */
  for (i=0;i< num_threads; i++)
    pthread_create (&th[i], NULL, code, NULL);
  
  pthread_exit (0);
    
}
