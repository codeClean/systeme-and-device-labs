#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>

void
nano_sleep(long  ns){
struct timespec tim, tim_remaining;

  tim.tv_sec = 0;
  tim.tv_nsec = ns;   // 0 to  999999999 nanosecond
  if (nanosleep(&tim, &tim_remaining) == -1 && errno == EINTR){
    fprintf(stderr, "nanosleep interrupted\n");
    exit(1);
  }

}


int millisleep(long milliseconds)
{
   struct timespec req, rem;

   if(milliseconds > 999)
   {   
        req.tv_sec = (int)(milliseconds / 1000);                            /* Must be Non-Negative */
        req.tv_nsec = (milliseconds - ((long)req.tv_sec * 1000)) * 1000000; /* Must be in range of 0 to 999999999 */
   }   
   else
   {   
        req.tv_sec = 0;                         /* Must be Non-Negative */
        req.tv_nsec = milliseconds * 1000000;    /* Must be in range of 0 to 999999999 */
   }   

   return nanosleep(&req , &rem);
}

int main()
{
   int ret = millisleep(2500);
   printf("sleep result %d\n",ret);
   return 0;
}
