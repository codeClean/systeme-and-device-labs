/*
 * Implements a precedence graph
  Get file name from the argument
  The main thread will 
  	- create the threads, 
  	- wait for them untill they update the global variables
  	- make some changes to the varaibles and allow the threads to procced 
	- take care the nth threads
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h> 
#include <string.h>
#include <ctype.h>
#include "pthread.h"

char next,this,last,*filename;
FILE *fd;

static void * inputThread(void *arg){
	char *c = (char *)arg;

	//sleep(2);
	 
	if(fd==NULL) { printf("error reading the file \n");}
    *c = fgetc(fd); 
   // while(c[0]==' '){  *c = fgetc(fd); printf("skipping space \n");}
    next = c[0]; 

	pthread_exit ((void *) 1);
}

static void * processThread(void *arg){
	 
	char *c = (char *)arg; 
	c[0] = this;
	*c = toupper(*c); 
    this = c[0]; 
    //sleep(2);

	pthread_exit ((void *) 1);
}
static void * outputThread(void *arg){
	char *c = (char *)arg;
	c[0] = last;  
 	sleep(1);
  	putchar(last); 
 	fflush(stdout);

	pthread_exit ((void *) 1);
	
}

int main(int argc, char const *argv[])
{
	 pthread_t *thi,*thp,*tho,inputThreadId,processId, outputId;
	 void * retval;
 	 int strl,rc,rc2,index,charlength;
	 long int  s;

	 if(argc!=2){printf("  %s usage: filename \n",argv[0] ); return 0;}

	 strl = strlen(argv[1]);
	 filename = (char *)malloc(sizeof(char)*strl+1);
	 strcpy(filename,argv[1]); 
 
	 fd = fopen(filename,"r");
	 fseek(fd, 0, SEEK_END); 
     charlength = ftell(fd);
     rewind(fd);
     printf("length of the characters = %d \n",charlength);

	next=' ';
	this=' ';
	last=' ';
	 

 /// creation of first input thread ///

	  thi  = (pthread_t *) malloc (sizeof(pthread_t));
	  inputThreadId = thi[0]; 
	 rc = pthread_create(&inputThreadId,NULL,inputThread,&next); 
	 if (rc) { fprintf (stderr, "ERROR: Pthread_create() core %d\n", rc); exit(-1);}

	 rc = pthread_join(inputThreadId,&retval); if(rc) { printf("error when joinning \n"); return 0;}
 	 this=next;


 /// creation of second  input thread ///

 	thi  = (pthread_t *) malloc (sizeof(pthread_t)); 
    inputThreadId = thi[1];
    processId = thp[0];

	rc = pthread_create(&inputThreadId,NULL,inputThread,&next); 
	rc2 = pthread_create(&processId,NULL,processThread,&this);

	 if (rc) { fprintf (stderr, "ERROR: Pthread_create() core %d\n", rc); exit(-1);} 
	 if (rc2) { fprintf (stderr, "ERROR: Pthread_create() core %d\n", rc); exit(-1);}

	 
	 if(pthread_join(processId,&retval)){ printf("error when process joinning \n"); return 0;}
	 if(pthread_join(inputThreadId,&retval)){ printf("error when thi 1joinning \n"); return 0;}	 
 

	 // s = (long int) retval; 
	// printf(" \n second process  tid %ld status  %ld \n",thp[0],s); 
	// printf(" got the first word '%s'   with status %d \n",next, *(int *) retval);

	 index = 1; // the first two are already asssigned for the previous creation of threads 
	  
  
	 while(index < charlength-2)
	 { 
	 	
	 	index++; 
	 	 last=this;
		 this=next;
	 	 thi  = (pthread_t *) malloc (sizeof(pthread_t));
	 	 inputThreadId = thi[index];
	 	 processId = thp[index-1];
	 	 outputId = tho[index-2];
		 pthread_create(&inputThreadId,NULL,inputThread,&next); 
		 pthread_create(&processId,NULL,processThread,&this); 
		 pthread_create(&outputId,NULL,outputThread,&last);
		 

		  if(pthread_join(inputThreadId,&retval)) { printf("error when process joinning \n"); return 0;}
		  if(pthread_join(processId,&retval)) { printf("error when process joinning \n"); return 0;}
		  if(pthread_join(outputId,&retval)) { printf("error when process joinning \n"); return 0;}
		   
 
		/* printf(" \n next = "); putchar(next); 
		 printf("   this = "); putchar(this);
		 printf("   last = "); putchar(last); */
		 //printf(" \n");  
	 	 
	 }

	 // the last two itratioins 
 	 last=this;
	 this=next;
  	  
 	 processId = thp[index];
 	 outputId = tho[index-1];
 
	 pthread_create(&processId,NULL,processThread,&this); 
	 pthread_create(&outputId,NULL,outputThread,&last);
	 
 	 if(pthread_join(processId,&retval)) { printf("error when process joinning \n"); return 0;}
	 if(pthread_join(outputId,&retval)) { printf("error when process joinning \n"); return 0;}
	   
 

 last=this;
  outputId = tho[index];
 
 	 pthread_create(&outputId,NULL,outputThread,&last);
	 
 	 if(pthread_join(outputId,&retval)) { printf("error when process joinning \n"); return 0;}

	 printf("\n");
	pthread_exit (NULL);
}
  